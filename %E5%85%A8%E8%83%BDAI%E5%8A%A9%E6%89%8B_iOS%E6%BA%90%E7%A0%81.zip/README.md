# 全能 AI 助手（iOS 源码项目）

这是一个 SwiftUI 起步项目，包含：
- DeepSeek、OpenAI、Gemini、Claude、Kimi、通义千问及自定义接口配置
- API Key、模型名、API 地址设置
- 中文语音识别输入、文字聊天、中文语音朗读

## 重要限制
- 这是**源码项目，不是已编译 IPA**。当前环境不能替你使用 Apple Xcode、开发者证书或全能签证书编译/签名。
- 需要一台 Mac 安装 Xcode，在 Xcode 新建一个 iOS App（SwiftUI，Swift），再将 `UniversalAIAssistant` 文件夹中的 4 个 Swift 文件加入 iOS App target，选择 iOS 18+，设置自己的 Bundle Identifier，再编译导出 IPA。
- iOS 语音识别需要在 Xcode target 的 Info 中添加：
  - `NSMicrophoneUsageDescription`：用于语音输入
  - `NSSpeechRecognitionUsageDescription`：用于将语音转换为文字
- Siri 启动：当前版本先支持通过 Siri“打开全能 AI 助手”启动 App；要实现 Siri 内直接发问并自动返回回答，需要继续加入 App Intents/Shortcuts 动作。
- API Key 目前保存在本机 AppStorage，适合个人测试，不适合公开分发。更安全的正式方案是自建后端代理并在服务器保管密钥。
- API 使用费用由各服务商单独计费；ChatGPT 订阅不包含 OpenAI API 额度。

## 构建
1. 在 Mac 上打开 Xcode，新建 iOS App（SwiftUI，Swift）。
2. 将本目录中的 4 个 `.swift` 文件加入 App target。
3. Deployment Target 设为 iOS 18.0 或更高。
4. 在 Info 添加上述两个隐私用途说明。
5. 连接 iPhone，选择你的开发团队签名并运行；或 Archive 后导出 IPA，再用全能签签名安装。

## 接口提示
默认 DeepSeek：
- Endpoint: `https://api.deepseek.com/chat/completions`
- Model: `deepseek-chat`

请以服务商控制台当前公布的模型名、接口地址和计费为准。
