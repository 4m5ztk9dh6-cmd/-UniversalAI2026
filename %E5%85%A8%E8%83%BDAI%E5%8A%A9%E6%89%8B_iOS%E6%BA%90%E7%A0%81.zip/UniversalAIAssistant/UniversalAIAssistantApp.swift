import SwiftUI

@main
struct UniversalAIAssistantApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
