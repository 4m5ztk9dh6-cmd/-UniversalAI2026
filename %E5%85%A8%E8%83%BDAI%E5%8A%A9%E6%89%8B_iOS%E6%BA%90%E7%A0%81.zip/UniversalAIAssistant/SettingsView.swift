import SwiftUI

struct SettingsView: View {
    @AppStorage("provider") private var providerName = AIProvider.deepseek.rawValue
    @AppStorage("apiKey") private var apiKey = ""
    @AppStorage("endpoint") private var endpoint = AIProvider.deepseek.defaultBaseURL
    @AppStorage("model") private var model = AIProvider.deepseek.defaultModel
    @State private var showKey = false

    private var provider: AIProvider { AIProvider(rawValue: providerName) ?? .deepseek }

    var body: some View {
        Form {
            Section("AI 服务商") {
                Picker("服务商", selection: $providerName) {
                    ForEach(AIProvider.allCases) { p in Text(p.rawValue).tag(p.rawValue) }
                }
                .onChange(of: providerName) { _, name in
                    let p = AIProvider(rawValue: name) ?? .deepseek
                    endpoint = p.defaultBaseURL
                    model = p.defaultModel
                    apiKey = ""
                }
                SecureField("API Key", text: $apiKey)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                TextField("模型名称", text: $model)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                TextField("API 地址", text: $endpoint)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
            }
            Section {
                Text("密钥仅保存在本机 App 设置中。正式公开发布时，建议改为自建后端代理，避免密钥被提取。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("说明") {
                Text("DeepSeek、OpenAI、Kimi、通义千问及自定义接口使用 OpenAI 兼容格式；Gemini 与 Claude 使用各自接口格式。不同服务商的模型名称、地区和账号权限可能不同。")
                    .font(.footnote)
            }
        }
        .navigationTitle("模型与密钥")
    }
}
