import SwiftUI
import Speech
import AVFoundation

struct ContentView: View {
    @AppStorage("provider") private var providerName = AIProvider.deepseek.rawValue
    @AppStorage("apiKey") private var apiKey = ""
    @AppStorage("endpoint") private var endpoint = AIProvider.deepseek.defaultBaseURL
    @AppStorage("model") private var model = AIProvider.deepseek.defaultModel
    @State private var input = ""
    @State private var messages: [ChatMessage] = []
    @State private var busy = false
    @State private var errorText = ""
    @State private var speaking = false
    @State private var recognizer = SpeechRecognizer()

    private var provider: AIProvider { AIProvider(rawValue: providerName) ?? .deepseek }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                HStack {
                    Text("当前模型：\(provider.rawValue)").font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    NavigationLink { SettingsView() } label: { Label("设置", systemImage: "gearshape") }
                }.padding(.horizontal)

                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 12) {
                        if messages.isEmpty {
                            ContentUnavailableView("全能 AI 助手", systemImage: "waveform", description: Text("选择 AI 服务商并填写 API Key，然后开始语音或文字对话。"))
                        }
                        ForEach(messages) { message in
                            HStack {
                                if message.role == "assistant" { bubble(message.content, mine: false); Spacer(minLength: 35) }
                                else { Spacer(minLength: 35); bubble(message.content, mine: true) }
                            }
                        }
                    }.padding()
                }

                if !errorText.isEmpty {
                    Text(errorText).font(.footnote).foregroundStyle(.red).padding(.horizontal)
                }

                HStack(spacing: 8) {
                    Button {
                        if recognizer.isRecording { recognizer.stop() } else { recognizer.start() }
                    } label: {
                        Image(systemName: recognizer.isRecording ? "stop.circle.fill" : "mic.circle.fill")
                            .font(.system(size: 34))
                    }
                    .accessibilityLabel("语音输入")

                    TextField("输入你想问的问题…", text: $input, axis: .vertical)
                        .textFieldStyle(.roundedBorder).lineLimit(1...4)

                    Button {
                        Task { await send() }
                    } label: {
                        Image(systemName: "arrow.up.circle.fill").font(.system(size: 32))
                    }.disabled(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || busy)
                }.padding()
                if recognizer.isRecording {
                    Text("正在听你说话…").font(.caption).foregroundStyle(.red)
                }
            }
            .navigationTitle("全能 AI 助手")
            .onChange(of: recognizer.transcribedText) { _, value in input = value }
            .onAppear { AVAudioSession.sharedInstance().requestRecordPermission { _ in } }
        }
    }

    private func bubble(_ text: String, mine: Bool) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(text).textSelection(.enabled)
            if !mine {
                Button { speak(text) } label: { Label("朗读", systemImage: "speaker.wave.2") }.font(.caption)
            }
        }
        .padding(12)
        .background(mine ? Color.blue.opacity(0.16) : Color.gray.opacity(0.15))
        .clipShape(RoundedRectangle(cornerRadius: 14))
    }

    @MainActor private func send() async {
        let question = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !question.isEmpty else { return }
        input = ""; errorText = ""; busy = true
        messages.append(ChatMessage(role: "user", content: question))
        if messages.first?.role != "system" {
            messages.insert(ChatMessage(role: "system", content: "你是全能 AI 助手。请用简体中文回答，表达清晰、直接。"), at: 0)
        }
        do {
            let answer = try await AIService.shared.send(messages, provider: provider, key: apiKey, endpoint: endpoint, model: model)
            messages.append(ChatMessage(role: "assistant", content: answer))
            speak(answer)
        } catch {
            errorText = error.localizedDescription
        }
        busy = false
    }

    private func speak(_ text: String) {
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "zh-CN")
        utterance.rate = 0.48
        AVSpeechSynthesizer().speak(utterance)
    }
}

final class SpeechRecognizer: ObservableObject {
    @Published var transcribedText = ""
    @Published var isRecording = false
    private let engine = AVAudioEngine()
    private let speech = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    func start() {
        SFSpeechRecognizer.requestAuthorization { [weak self] status in
            guard status == .authorized else { return }
            DispatchQueue.main.async { self?.begin() }
        }
    }

    private func begin() {
        do {
            transcribedText = ""; isRecording = true
            let audio = AVAudioSession.sharedInstance()
            try audio.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audio.setActive(true, options: .notifyOthersOnDeactivation)
            request = SFSpeechAudioBufferRecognitionRequest()
            guard let request else { return }
            let node = engine.inputNode
            let format = node.outputFormat(forBus: 0)
            node.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in request.append(buffer) }
            engine.prepare(); try engine.start()
            task = speech?.recognitionTask(with: request) { [weak self] result, _ in
                if let result { DispatchQueue.main.async { self?.transcribedText = result.bestTranscription.formattedString } }
            }
        } catch { isRecording = false }
    }

    func stop() {
        engine.stop(); engine.inputNode.removeTap(onBus: 0)
        request?.endAudio(); task?.cancel()
        isRecording = false
    }
}
