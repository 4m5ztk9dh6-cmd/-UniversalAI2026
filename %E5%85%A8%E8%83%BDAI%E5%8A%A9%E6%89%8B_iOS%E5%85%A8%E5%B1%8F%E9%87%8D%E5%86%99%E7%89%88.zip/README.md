# 全能 AI 助手 iOS 项目（全屏适配重写版）

## 本版更新
- 背景延伸至整个屏幕；页面内容遵循 iOS 安全区域，自动避开灵动岛、状态栏和底部 Home 指示条。
- 输入栏使用 `safeAreaInset(edge: .bottom)`，键盘出现时随安全区域自动上移，不遮挡输入框；支持交互式收起键盘。
- 移除固定屏幕宽高布局，使用 SwiftUI 自适应布局。
- 配置 `Info.plist`、麦克风/语音识别权限说明和 `LaunchScreen.storyboard`。
- 保留 DeepSeek、OpenAI、Gemini、Claude、Kimi、通义千问、自定义接口、API Key、语音输入、AI 回复、语音朗读和设置页。
- 修正语音识别对象的观察方式，并增加麦克风/语音权限错误提示。

## 项目文件
- `UniversalAIAssistant/`：Swift 源码
- `Info.plist`：应用信息和隐私权限说明
- `Resources/LaunchScreen.storyboard`：启动页
- `project.yml`：XcodeGen 项目配置
- `.github/workflows/build.yml`：GitHub Actions 云编译工作流

## GitHub 云编译
1. 将本项目全部文件上传到 GitHub 仓库根目录（保留 `.github/workflows/build.yml`）。
2. 打开仓库的 Actions 页面，选择 **Build iOS IPA**，点击 **Run workflow**。
3. 编译成功后打开本次运行记录，在 Artifacts 下载 `UniversalAIAssistant-IPA`。
4. 解压后得到未签名 IPA，再使用你自己的签名工具签名安装。该 IPA 尚未签名，不能直接安装。

## 重要说明
- 这是个人测试用途的未签名构建。GitHub Actions 只能编译，不能替你提供 Apple 开发者证书或签名。
- iOS 语音识别首次使用时会请求麦克风和语音识别权限。
- API Key 保存在本机 AppStorage。不要将真实 Key 写入源码或公开仓库。
- API 费用由各 AI 服务商单独收取；ChatGPT 订阅不包含 OpenAI API 额度。
- 当前可通过 Siri 说“打开全能 AI 助手”启动 App；Siri 内直接对话需要另行实现 App Intents。
