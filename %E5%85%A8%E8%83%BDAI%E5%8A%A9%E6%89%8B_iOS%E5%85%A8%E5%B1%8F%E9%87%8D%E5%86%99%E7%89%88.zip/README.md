# 全能 AI 助手（iOS）

## 功能
- 默认 DeepSeek，支持 OpenAI、Gemini、Claude、Kimi、通义千问和自定义 OpenAI 兼容接口
- 每个服务商独立使用 iOS Keychain 保存 API Key；切换服务商自动读取对应密钥
- 设置页眼睛按钮可切换密钥明文/隐藏显示
- 深色/浅色主题全局统一，并使用 AppStorage 独立持久化
- 中文语音输入、AI 语音朗读
- 自定义模型名称与 API 地址
- SwiftUI 根窗口自适应，不设置固定宽高；背景延伸至屏幕边缘，内容遵守安全区域，输入栏使用 safeAreaInset 跟随键盘
- LaunchScreen.storyboard 作为构建资源编译
- 在支持 ProMotion 的 iPhone 上允许系统使用高于 60Hz 的刷新率（最高可达设备支持的 120Hz）

## 构建与产物验证
GitHub Actions 在 macOS runner 上使用 XcodeGen 生成 Xcode 工程并构建未签名 iOS App。Xcode target 自带构建后校验脚本，因此即使由仓库中原有的 ZIP 解压型 Actions 工作流触发，构建步骤本身也会检查最终 App。随后工作流还会检查：
- 最终 App 的 `UILaunchStoryboardName` 指向 `LaunchScreen`
- `LaunchScreen.storyboardc` 确实编译进 `.app` 包
- `UIDeviceFamily` 包含 iPhone
- ProMotion 高刷新率许可键已写入最终 `Info.plist`
- 主可执行文件存在且为 Mach-O
- 重新解压 IPA 后再次检查启动页资源和主可执行文件

下载的 IPA 仍需使用个人证书/全能签签名后才能安装。当前环境不是 macOS/Xcode，不能在此处代替 GitHub Actions 完成真实 iOS 编译；请以 Actions 的构建与产物校验结果为准。

## ProMotion 说明
工程通过 `CADisableMinimumFrameDurationOnPhone = YES` 解除 iPhone 应用默认的最低帧时长限制，让系统可在支持的设备上调度最高 120Hz。刷新率仍由 iOS 根据屏幕内容、温度、电量和系统策略动态决定，应用不能保证每一帧都固定运行在 120Hz。

## 全屏说明
iPhone 应用窗口由 iOS 管理，SwiftUI `WindowGroup` 使用自适应根视图，没有固定窗口高度、手动 scene 尺寸或 iPad 多任务窗口逻辑。`UIRequiresFullScreen` 是 iPad 多任务相关设置，不是 iPhone 黑边修复开关，因此不再把它当作修复手段。LaunchScreen 只负责启动过渡画面；Actions 会验证它确实进入最终 App/IPA。若真机仍出现上下黑边且键盘也被限制，需进一步检查设备上的安装包是否确为本次 Actions 产物、iOS 显示缩放/辅助功能设置及系统实际窗口行为。

## 安全
API Key 只保存在系统 Keychain，不写入 AppStorage。不要把真实密钥写入源码或提交到公开仓库。API 调用由对应服务商单独计费，ChatGPT 订阅不包含 OpenAI API 额度。
