import Foundation

enum AIServiceError: LocalizedError {
    case missingKey, badURL, badResponse, server(String), unsupportedProvider
    var errorDescription: String? {
        switch self {
        case .missingKey: return "请先填写当前服务商的 API Key。"
        case .badURL: return "API 地址不正确。"
        case .badResponse: return "服务商返回内容无法识别。"
        case .server(let s): return s
        case .unsupportedProvider: return "该接口暂不支持，请使用 OpenAI 兼容接口或 Gemini。"
        }
    }
}

final class AIService {
    static let shared = AIService()
    private init() {}

    func send(_ messages: [ChatMessage], provider: AIProvider, key: String, endpoint: String, model: String) async throws -> String {
        guard !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AIServiceError.missingKey }
        guard let url = URL(string: endpoint), url.scheme != nil else { throw AIServiceError.badURL }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 60

        if provider == .gemini {
            request.url = URL(string: "\(endpoint)/\(model):generateContent?key=\(key.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? key)")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let contents = messages.filter { $0.role != "system" }.map {
                ["role": $0.role == "assistant" ? "model" : "user",
                 "parts": [["text": $0.content]]] as [String : Any]
            }
            request.httpBody = try JSONSerialization.data(withJSONObject: ["contents": contents])
        } else if provider == .claude {
            request.setValue(key, forHTTPHeaderField: "x-api-key")
            request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let system = messages.first(where: { $0.role == "system" })?.content ?? "你是一个有帮助的中文 AI 助手。"
            let turns = messages.filter { $0.role != "system" }.map { ["role": $0.role, "content": $0.content] }
            request.httpBody = try JSONSerialization.data(withJSONObject: [
                "model": model, "max_tokens": 2048, "system": system, "messages": turns
            ])
        } else {
            request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let turns = messages.map { ["role": $0.role, "content": $0.content] }
            request.httpBody = try JSONSerialization.data(withJSONObject: [
                "model": model, "messages": turns, "temperature": 0.7
            ])
        }

        let (data, response) = try await URLSession.shared.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(status) else {
            let body = String(data: data, encoding: .utf8) ?? "HTTP \(status)"
            throw AIServiceError.server("接口错误（\(status)）：\(body.prefix(500))")
        }

        guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw AIServiceError.badResponse }
        if provider == .gemini {
            let candidates = json["candidates"] as? [[String: Any]]
            let content = candidates?.first?["content"] as? [String: Any]
            let parts = content?["parts"] as? [[String: Any]]
            if let text = parts?.compactMap({ $0["text"] as? String }).joined(), !text.isEmpty { return text }
        } else if provider == .claude {
            let content = json["content"] as? [[String: Any]]
            if let text = content?.compactMap({ $0["text"] as? String }).joined(), !text.isEmpty { return text }
        } else {
            let choices = json["choices"] as? [[String: Any]]
            let message = choices?.first?["message"] as? [String: Any]
            if let text = message?["content"] as? String { return text }
        }
        throw AIServiceError.badResponse
    }
}
