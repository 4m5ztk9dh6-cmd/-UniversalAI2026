import SwiftUI

@main
struct UniversalAIAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .background(Color(red: 0.025, green: 0.045, blue: 0.09))
                .ignoresSafeArea(.container, edges: [])
        }
    }
}
