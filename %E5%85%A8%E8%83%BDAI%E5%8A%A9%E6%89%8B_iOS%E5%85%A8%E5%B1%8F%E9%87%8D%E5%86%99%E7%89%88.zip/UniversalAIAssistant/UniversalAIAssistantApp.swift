import SwiftUI

@main
struct UniversalAIAssistantApp: App {
    @AppStorage("appTheme") private var appTheme = "dark"

    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.clear)
                .preferredColorScheme(appTheme == "light" ? .light : .dark)
        }
    }
}
