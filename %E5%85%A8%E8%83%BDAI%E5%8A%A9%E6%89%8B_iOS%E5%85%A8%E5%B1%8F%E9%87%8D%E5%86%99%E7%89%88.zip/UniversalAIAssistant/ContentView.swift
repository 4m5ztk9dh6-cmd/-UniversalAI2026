import SwiftUI
import Speech
import AVFoundation

struct ContentView: View {
    @AppStorage("provider") private var providerName = AIProvider.deepseek.rawValue
    @State private var apiKey = ""
    @AppStorage("appTheme") private var appTheme = "dark"

    private var isDark: Bool { appTheme != "light" }
    @AppStorage("endpoint") private var endpoint = AIProvider.deepseek.defaultBaseURL
    @AppStorage("model") private var model = AIProvider.deepseek.defaultModel

    @State private var input = ""
    @State private var messages: [ChatMessage] = []
    @State private var busy = false
    @State private var errorText = ""
    @StateObject private var recognizer = SpeechRecognizer()
    @FocusState private var inputFocused: Bool
    @State private var speechSynthesizer = AVSpeechSynthesizer()

    private var provider: AIProvider { AIProvider(rawValue: providerName) ?? .deepseek }

    var body: some View {
        ZStack {
            AppBackground(isDark: isDark)
                .ignoresSafeArea(edges: .all)

            NavigationStack {
                VStack(spacing: 0) {
                    providerHeader

                    conversation
                        .frame(maxWidth: .infinity, maxHeight: .infinity)

                    if !errorText.isEmpty {
                        Text(errorText)
                            .font(.footnote)
                            .foregroundStyle(.red)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 16)
                            .padding(.top, 6)
                    }
                }
                .background(Color.clear)
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    composer
                }
                .navigationTitle("全能 AI 助手")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink {
                            SettingsView()
                        } label: {
                            Image(systemName: "gearshape.fill")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(.primary)
                        }
                        .accessibilityLabel("设置")
                    }
                }
                .toolbarBackground(.hidden, for: .navigationBar)
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: recognizer.transcribedText) { _, value in
                    input = value
                }
                .onChange(of: providerName) { _, _ in
                    errorText = ""
                }
            }
            .tint(.cyan)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .preferredColorScheme(isDark ? .dark : .light)
        .onAppear {
            apiKey = KeychainStore.load(account: provider.rawValue) ?? ""
        }
        .onChange(of: providerName) { _, name in
            let selected = AIProvider(rawValue: name) ?? .deepseek
            apiKey = KeychainStore.load(account: selected.rawValue) ?? ""
        }
    }

    private var providerHeader: some View {
        HStack(spacing: 8) {
            Circle()
                .fill(Color.cyan)
                .frame(width: 7, height: 7)
                .shadow(color: .cyan.opacity(0.8), radius: 6)
            Text("当前模型：\(provider.rawValue)")
                .font(.caption.weight(.medium))
                .foregroundStyle(isDark ? Color.white.opacity(0.72) : Color.black.opacity(0.68))
            Spacer()
            if busy {
                ProgressView().tint(.cyan).scaleEffect(0.8)
                Text("思考中")
                    .font(.caption2)
                    .foregroundStyle(isDark ? Color.white.opacity(0.6) : Color.black.opacity(0.58))
            }
        }
        .padding(.horizontal, 18)
        .padding(.top, 7)
        .padding(.bottom, 10)
    }

    private var conversation: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 14) {
                    if messages.isEmpty {
                        welcomeCard
                            .padding(.top, 28)
                    }

                    ForEach(messages) { message in
                        HStack(alignment: .top, spacing: 8) {
                            if message.role == "assistant" {
                                assistantAvatar
                                messageBubble(message.content, mine: false)
                                Spacer(minLength: 24)
                            } else if message.role == "user" {
                                Spacer(minLength: 34)
                                messageBubble(message.content, mine: true)
                            }
                        }
                        .id(message.id)
                    }

                    if busy {
                        HStack(spacing: 9) {
                            assistantAvatar
                            HStack(spacing: 5) {
                                ProgressView().tint(.cyan)
                                Text("正在生成回答…")
                                    .font(.caption)
                                    .foregroundStyle(isDark ? Color.white.opacity(0.65) : Color.black.opacity(0.62))
                            }
                            .padding(12)
                            .background((isDark ? Color.white : Color.black).opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
                            Spacer()
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
            }
            .defaultScrollAnchor(.bottom)
            .onChange(of: messages.count) { _, _ in
                guard let lastID = messages.last?.id else { return }
                withAnimation(.easeOut(duration: 0.25)) { proxy.scrollTo(lastID, anchor: .bottom) }
            }
        }
    }

    private var welcomeCard: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle().fill(Color.cyan.opacity(0.12)).frame(width: 94, height: 94)
                Image(systemName: "sparkles")
                    .font(.system(size: 40, weight: .medium))
                    .foregroundStyle(LinearGradient(colors: [.cyan, .blue, .purple], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
            Text("你好，我是全能 AI 助手")
                .font(.title3.bold())
                .foregroundStyle(isDark ? Color.white : Color.primary)
            Text("可以直接输入问题，也可以点击麦克风进行语音输入。")
                .font(.subheadline)
                .foregroundStyle(isDark ? Color.white.opacity(0.62) : Color.black.opacity(0.62))
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
            Text("先在右上角设置中填写 API Key")
                .font(.caption.weight(.medium))
                .foregroundStyle(.cyan)
                .padding(.horizontal, 13)
                .padding(.vertical, 8)
                .background(Color.cyan.opacity(0.1), in: Capsule())
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background((isDark ? Color.white : Color.black).opacity(0.045), in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke((isDark ? Color.white : Color.black).opacity(0.08), lineWidth: 1))
    }

    private var assistantAvatar: some View {
        Image(systemName: "sparkles")
            .font(.system(size: 13, weight: .bold))
            .foregroundStyle(.black)
            .frame(width: 28, height: 28)
            .background(LinearGradient(colors: [.cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing), in: Circle())
    }

    private func messageBubble(_ text: String, mine: Bool) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(text)
                .font(.body)
                .foregroundStyle(isDark ? Color.white.opacity(0.94) : Color.black.opacity(0.9))
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
            if !mine {
                Button {
                    speak(text)
                } label: {
                    Label("朗读", systemImage: "speaker.wave.2.fill")
                        .font(.caption.weight(.medium))
                }
                .buttonStyle(.plain)
                .foregroundStyle(.cyan)
            }
        }
        .padding(13)
        .background(
            mine ? Color.blue.opacity(0.22) : (isDark ? Color.white.opacity(0.075) : Color.black.opacity(0.045)),
            in: RoundedRectangle(cornerRadius: 17, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 17, style: .continuous)
                .stroke((isDark ? Color.white : Color.black).opacity(mine ? 0.08 : 0.1), lineWidth: 1)
        }
        .frame(maxWidth: 620, alignment: mine ? .trailing : .leading)
    }

    private var composer: some View {
        VStack(spacing: 7) {
            if !recognizer.permissionError.isEmpty {
                Text(recognizer.permissionError)
                    .font(.caption)
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 5)
            }
            if recognizer.isRecording {
                HStack(spacing: 7) {
                    Circle().fill(.red).frame(width: 7, height: 7)
                    Text("正在听你说话…再次点击麦克风结束")
                        .font(.caption)
                        .foregroundStyle(.red.opacity(0.9))
                    Spacer()
                }
                .padding(.horizontal, 5)
            }

            HStack(alignment: .bottom, spacing: 10) {
                Button {
                    if recognizer.isRecording { recognizer.stop() }
                    else { recognizer.start() }
                } label: {
                    Image(systemName: recognizer.isRecording ? "stop.circle.fill" : "mic.circle.fill")
                        .font(.system(size: 34))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(recognizer.isRecording ? .red : .cyan, .white.opacity(0.15))
                }
                .accessibilityLabel(recognizer.isRecording ? "停止语音输入" : "语音输入")

                TextField("输入你想问的问题…", text: $input, axis: .vertical)
                    .font(.body)
                    .lineLimit(1...5)
                    .focused($inputFocused)
                    .submitLabel(.send)
                    .onSubmit { Task { await send() } }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 11)
                    .foregroundStyle(isDark ? Color.white : Color.primary)
                    .background((isDark ? Color.white : Color.black).opacity(0.09), in: RoundedRectangle(cornerRadius: 18))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke((isDark ? Color.white : Color.black).opacity(0.1), lineWidth: 1))

                Button {
                    Task { await send() }
                } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.system(size: 35))
                        .foregroundStyle(canSend ? Color.cyan : Color.gray.opacity(0.55))
                }
                .disabled(!canSend)
                .accessibilityLabel("发送消息")
            }
        }
        .padding(.horizontal, 14)
        .padding(.top, 10)
        .padding(.bottom, 8)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Rectangle().fill((isDark ? Color.white : Color.black).opacity(0.08)).frame(height: 1) }
    }

    private var canSend: Bool {
        !input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !busy
    }

    @MainActor private func send() async {
        let question = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !question.isEmpty, !busy else { return }
        input = ""
        inputFocused = false
        errorText = ""
        busy = true

        if messages.first(where: { $0.role == "system" }) == nil {
            messages.insert(ChatMessage(role: "system", content: "你是全能 AI 助手。请用简体中文回答，表达清晰、直接。"), at: 0)
        }
        messages.append(ChatMessage(role: "user", content: question))

        do {
            let answer = try await AIService.shared.send(messages, provider: provider, key: (KeychainStore.load(account: provider.rawValue) ?? apiKey), endpoint: endpoint, model: model)
            messages.append(ChatMessage(role: "assistant", content: answer))
            speak(answer)
        } catch {
            errorText = error.localizedDescription
        }
        busy = false
    }

    private func speak(_ text: String) {
        speechSynthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "zh-CN")
        utterance.rate = 0.48
        speechSynthesizer.speak(utterance)
    }
}

private struct AppBackground: View {
    let isDark: Bool
    var body: some View {
        LinearGradient(
            colors: isDark
                ? [Color(red: 0.025, green: 0.045, blue: 0.09), Color(red: 0.035, green: 0.075, blue: 0.14), Color(red: 0.025, green: 0.035, blue: 0.075)]
                : [Color(red: 0.96, green: 0.98, blue: 1.0), Color(red: 0.91, green: 0.95, blue: 0.99), Color(red: 0.97, green: 0.98, blue: 1.0)],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .overlay(alignment: .topTrailing) {
            Circle().fill(Color.blue.opacity(isDark ? 0.13 : 0.07)).frame(width: 280, height: 280).blur(radius: 85).offset(x: 100, y: -90)
        }
        .overlay(alignment: .bottomLeading) {
            Circle().fill(Color.cyan.opacity(isDark ? 0.09 : 0.08)).frame(width: 260, height: 260).blur(radius: 90).offset(x: -100, y: 100)
        }
    }
}

final class SpeechRecognizer: ObservableObject {
    @Published var transcribedText = ""
    @Published var isRecording = false
    @Published var permissionError = ""

    private let engine = AVAudioEngine()
    private let speech = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    func start() {
        SFSpeechRecognizer.requestAuthorization { [weak self] status in
            guard let self else { return }
            guard status == .authorized else {
                DispatchQueue.main.async { self.permissionError = "请在系统设置中允许语音识别权限。" }
                return
            }
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                guard granted else {
                    DispatchQueue.main.async { self.permissionError = "请在系统设置中允许麦克风权限。" }
                    return
                }
                DispatchQueue.main.async { self.begin() }
            }
        }
    }

    private func begin() {
        guard !engine.isRunning else { return }
        do {
            transcribedText = ""
            permissionError = ""
            let audio = AVAudioSession.sharedInstance()
            try audio.setCategory(.record, mode: .measurement, options: [.duckOthers])
            try audio.setActive(true, options: .notifyOthersOnDeactivation)

            let recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            recognitionRequest.shouldReportPartialResults = true
            request = recognitionRequest

            let node = engine.inputNode
            let format = node.outputFormat(forBus: 0)
            node.removeTap(onBus: 0)
            node.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
                recognitionRequest.append(buffer)
            }
            engine.prepare()
            try engine.start()
            isRecording = true

            task = speech?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
                if let result {
                    DispatchQueue.main.async { self?.transcribedText = result.bestTranscription.formattedString }
                }
                if error != nil {
                    DispatchQueue.main.async { self?.stop() }
                }
            }
        } catch {
            permissionError = "无法启动语音输入：\(error.localizedDescription)"
            stop()
        }
    }

    func stop() {
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        request = nil
        task = nil
        isRecording = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}
