import SwiftUI

struct SettingsView: View {
    @AppStorage("provider") private var providerName = AIProvider.deepseek.rawValue
    @AppStorage("apiKey") private var apiKey = ""
    @AppStorage("endpoint") private var endpoint = AIProvider.deepseek.defaultBaseURL
    @AppStorage("model") private var model = AIProvider.deepseek.defaultModel
    @State private var showKey = false

    private var provider: AIProvider { AIProvider(rawValue: providerName) ?? .deepseek }

    var body: some View {
        ZStack {
            SettingsBackground().ignoresSafeArea()
            Form {
                Section {
                    Picker("服务商", selection: $providerName) {
                        ForEach(AIProvider.allCases) { item in
                            Text(item.rawValue).tag(item.rawValue)
                        }
                    }
                    .onChange(of: providerName) { _, name in
                        let selected = AIProvider(rawValue: name) ?? .deepseek
                        endpoint = selected.defaultBaseURL
                        model = selected.defaultModel
                        apiKey = ""
                    }

                    HStack {
                        Group {
                            if showKey {
                                TextField("API Key", text: $apiKey)
                            } else {
                                SecureField("API Key", text: $apiKey)
                            }
                        }
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        Button {
                            showKey.toggle()
                        } label: {
                            Image(systemName: showKey ? "eye.slash" : "eye")
                                .foregroundStyle(.secondary)
                        }
                        .buttonStyle(.plain)
                    }

                    TextField("模型名称", text: $model)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("API 地址", text: $endpoint, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .lineLimit(1...3)
                } header: {
                    Text("AI 服务商")
                } footer: {
                    Text("当前选择：\(provider.rawValue)。切换服务商会载入对应的默认模型和接口地址。")
                }

                Section("隐私与安全") {
                    Label("API Key 保存在本机", systemImage: "lock.shield")
                    Text("此版本使用本机偏好设置保存密钥，适合个人测试。不要把含有真实 API Key 的项目公开上传到公共仓库。正式发布建议使用自己的后端代理保护密钥。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("使用说明") {
                    Text("DeepSeek、OpenAI、Kimi、通义千问和自定义接口使用 OpenAI 兼容格式；Gemini 与 Claude 使用各自的接口格式。请以服务商控制台当前公布的模型名、接口地址和账号权限为准。")
                        .font(.footnote)
                    Text("API 调用费用由对应服务商单独收取，ChatGPT 订阅不包含 OpenAI API 额度。")
                        .font(.footnote)
                }
            }
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("模型与密钥")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct SettingsBackground: View {
    var body: some View {
        LinearGradient(colors: [Color(red: 0.025, green: 0.045, blue: 0.09), Color(red: 0.04, green: 0.08, blue: 0.14)], startPoint: .top, endPoint: .bottom)
    }
}
