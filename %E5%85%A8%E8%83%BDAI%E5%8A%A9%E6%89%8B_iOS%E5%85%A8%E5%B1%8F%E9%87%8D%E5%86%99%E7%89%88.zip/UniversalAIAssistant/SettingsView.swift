import SwiftUI

struct SettingsView: View {
    @AppStorage("provider") private var providerName = AIProvider.deepseek.rawValue
    @AppStorage("endpoint") private var endpoint = AIProvider.deepseek.defaultBaseURL
    @AppStorage("model") private var model = AIProvider.deepseek.defaultModel
    @AppStorage("appTheme") private var appTheme = "dark"
    // Legacy key from previous builds. It is migrated once into the selected provider's Keychain slot.
    @AppStorage("apiKey") private var legacyAPIKey = ""

    @State private var apiKey = ""
    @State private var showKey = false
    @State private var keychainError = ""
    @FocusState private var keyFocused: Bool

    private var provider: AIProvider { AIProvider(rawValue: providerName) ?? .deepseek }

    var body: some View {
        ZStack {
            SettingsBackground(isDark: appTheme == "dark").ignoresSafeArea()
            Form {
                Section("外观主题") {
                    Picker("主题模式", selection: $appTheme) {
                        Text("深色模式").tag("dark")
                        Text("浅色模式").tag("light")
                    }
                    .pickerStyle(.segmented)
                    Text("主题选择会自动保存在本机，并应用到整个 App。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Picker("服务商", selection: $providerName) {
                        ForEach(AIProvider.allCases) { item in
                            Text(item.rawValue).tag(item.rawValue)
                        }
                    }
                    .onChange(of: providerName) { _, name in
                        let selected = AIProvider(rawValue: name) ?? .deepseek
                        apiKey = KeychainStore.load(account: selected.rawValue) ?? ""
                        keychainError = ""
                        endpoint = selected.defaultBaseURL
                        model = selected.defaultModel
                    }

                    HStack(spacing: 10) {
                        Group {
                            if showKey {
                                TextField("API Key", text: $apiKey)
                            } else {
                                SecureField("API Key", text: $apiKey)
                            }
                        }
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textContentType(.password)
                        .focused($keyFocused)

                        Button { showKey.toggle() } label: {
                            Image(systemName: showKey ? "eye.slash.fill" : "eye.fill")
                                .foregroundStyle(.secondary)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(showKey ? "隐藏 API Key" : "明文查看 API Key")
                    }
                    .onChange(of: apiKey) { _, value in
                        let saved = value.isEmpty
                            ? KeychainStore.delete(account: provider.rawValue)
                            : KeychainStore.save(value, account: provider.rawValue)
                        keychainError = saved ? "" : "无法写入系统 Keychain，请检查设备设置后重试。"
                    }

                    if !keychainError.isEmpty {
                        Text(keychainError).font(.footnote).foregroundStyle(.red)
                    }

                    TextField("模型名称", text: $model)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("API 地址", text: $endpoint, axis: .vertical)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .lineLimit(1...3)
                } header: {
                    Text("AI 服务商")
                } footer: {
                    Text("每个服务商单独保存 API Key。切换服务商会自动读取对应密钥，不会覆盖其他服务商的密钥。当前服务商：\(provider.rawValue)。")
                }

                Section("隐私与安全") {
                    Label("API Key 保存在本机系统 Keychain", systemImage: "lock.shield")
                    Text("密钥不会再写入 AppStorage。卸载或更换设备后的保留情况由 iOS 钥匙串策略决定。不要把真实 API Key 提交到公开源码仓库。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                Section("使用说明") {
                    Text("DeepSeek、OpenAI、Kimi、通义千问和自定义接口使用 OpenAI 兼容格式；Gemini 与 Claude 使用各自的接口格式。请以服务商控制台当前公布的模型名、接口地址和账号权限为准。")
                        .font(.footnote)
                    Text("API 调用费用由对应服务商单独收取，ChatGPT 订阅不包含 OpenAI API 额度。")
                        .font(.footnote)
                }
            }
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("模型与设置")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: loadCurrentKey)
        .onDisappear { keyFocused = false }
    }

    private func loadCurrentKey() {
        if let current = KeychainStore.load(account: provider.rawValue) {
            apiKey = current
            return
        }

        // One-time compatibility migration: older versions used a shared Keychain item
        // and/or UserDefaults key. Assign it only to the currently selected provider.
        let oldSharedKey = KeychainStore.load(account: "shared-api-key")
        let legacy = oldSharedKey ?? legacyAPIKey
        if !legacy.isEmpty {
            if KeychainStore.save(legacy, account: provider.rawValue) {
                apiKey = legacy
                _ = KeychainStore.delete(account: "shared-api-key")
                legacyAPIKey = ""
            }
        }
    }
}

private struct SettingsBackground: View {
    let isDark: Bool
    var body: some View {
        LinearGradient(
            colors: isDark
                ? [Color(red: 0.025, green: 0.045, blue: 0.09), Color(red: 0.04, green: 0.08, blue: 0.14)]
                : [Color(red: 0.97, green: 0.985, blue: 1), Color(red: 0.91, green: 0.95, blue: 0.99)],
            startPoint: .top,
            endPoint: .bottom
        )
    }
}
