import Foundation

enum AIProvider: String, CaseIterable, Identifiable {
    case deepseek = "DeepSeek"
    case openAI = "OpenAI"
    case gemini = "Google Gemini"
    case claude = "Anthropic Claude"
    case kimi = "Moonshot Kimi"
    case qwen = "通义千问"
    case custom = "自定义 OpenAI 兼容接口"

    var id: String { rawValue }

    var defaultBaseURL: String {
        switch self {
        case .deepseek: return "https://api.deepseek.com/chat/completions"
        case .openAI: return "https://api.openai.com/v1/chat/completions"
        case .gemini: return "https://generativelanguage.googleapis.com/v1beta/models"
        case .claude: return "https://api.anthropic.com/v1/messages"
        case .kimi: return "https://api.moonshot.cn/v1/chat/completions"
        case .qwen: return "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
        case .custom: return ""
        }
    }

    var defaultModel: String {
        switch self {
        case .deepseek: return "deepseek-chat"
        case .openAI: return "gpt-4o-mini"
        case .gemini: return "gemini-2.0-flash"
        case .claude: return "claude-3-5-haiku-latest"
        case .kimi: return "moonshot-v1-8k"
        case .qwen: return "qwen-turbo"
        case .custom: return ""
        }
    }
}

struct ChatMessage: Codable, Identifiable {
    var id = UUID()
    let role: String
    let content: String
}
